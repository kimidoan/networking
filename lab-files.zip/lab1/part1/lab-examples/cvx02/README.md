Example of how to run `cvx` nodes inside docker runtime.

